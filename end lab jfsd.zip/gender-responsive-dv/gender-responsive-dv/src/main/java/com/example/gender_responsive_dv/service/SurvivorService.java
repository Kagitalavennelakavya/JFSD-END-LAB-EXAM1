package com.example.gender_responsive_dv.service;


import com.example.gender_responsive_dv.model.Survivor;
import com.example.gender_responsive_dv.repository.SurvivorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SurvivorService {
    @Autowired
    private SurvivorRepository survivorRepository;

    // Get all survivors
    public List<Survivor> getAllSurvivors() {
        return survivorRepository.findAll();
    }

    // Save a new survivor
    public Survivor saveSurvivor(Survivor survivor) {
        return survivorRepository.save(survivor);
    }

    // Find a survivor by ID
    public Optional<Survivor> getSurvivorById(Long id) {
        return survivorRepository.findById(id);
    }

    // Delete a survivor by ID
    public void deleteSurvivor(Long id) {
        survivorRepository.deleteById(id);
    }
}