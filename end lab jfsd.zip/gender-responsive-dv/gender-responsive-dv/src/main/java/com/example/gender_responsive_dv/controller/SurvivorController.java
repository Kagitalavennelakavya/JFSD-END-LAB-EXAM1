package com.example.gender_responsive_dv.controller;

import com.example.gender_responsive_dv.model.Survivor;
import com.example.gender_responsive_dv.service.SurvivorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/survivors")
public class SurvivorController {
    @Autowired
    private SurvivorService survivorService;

    // Get all survivors
    @GetMapping
    public List<Survivor> getAllSurvivors() {
        return survivorService.getAllSurvivors();
    }

    // Get a survivor by ID
    @GetMapping("/{id}")
    public ResponseEntity<Survivor> getSurvivorById(@PathVariable Long id) {
        Optional<Survivor> survivor = survivorService.getSurvivorById(id);
        return survivor.map(ResponseEntity::ok)
                       .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    // Create a new survivor
    @PostMapping
    public ResponseEntity<Survivor> createSurvivor(@RequestBody Survivor survivor) {
        Survivor savedSurvivor = survivorService.saveSurvivor(survivor);
        return new ResponseEntity<>(savedSurvivor, HttpStatus.CREATED);
    }

    // Delete a survivor by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSurvivor(@PathVariable Long id) {
        survivorService.deleteSurvivor(id);
        return ResponseEntity.noContent().build();
    }
}