package com.example.gender_responsive_dv.repository;

import com.example.gender_responsive_dv.model.Survivor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SurvivorRepository extends JpaRepository<Survivor, Long> {
}