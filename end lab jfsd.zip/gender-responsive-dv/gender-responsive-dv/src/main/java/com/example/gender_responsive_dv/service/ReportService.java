package com.example.gender_responsive_dv.service;

import com.example.gender_responsive_dv.model.Report;
import com.example.gender_responsive_dv.repository.ReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReportService {
    @Autowired
    private ReportRepository reportRepository;

    // Get all reports
    public List<Report> getAllReports() {
        return reportRepository.findAll();
    }

    // Save a new report
    public Report saveReport(Report report) {
        return reportRepository.save(report);
    }

    // Find a report by ID
    public Optional<Report> getReportById(Long id) {
        return reportRepository.findById(id);
    }

    // Delete a report by ID
    public void deleteReport(Long id) {
        reportRepository.deleteById(id);
    }
}