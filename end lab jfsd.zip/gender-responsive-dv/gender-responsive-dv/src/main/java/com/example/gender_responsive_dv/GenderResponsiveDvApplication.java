package com.example.gender_responsive_dv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenderResponsiveDvApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenderResponsiveDvApplication.class, args);
	}

}
