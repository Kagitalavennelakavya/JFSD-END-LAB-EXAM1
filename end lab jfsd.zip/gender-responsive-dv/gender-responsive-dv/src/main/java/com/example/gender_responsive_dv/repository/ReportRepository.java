package com.example.gender_responsive_dv.repository;


import com.example.gender_responsive_dv.model.Report;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository extends JpaRepository<Report, Long> {
}