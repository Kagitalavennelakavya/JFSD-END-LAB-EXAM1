package com.example.gender_responsive_dv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenderResponsiveDvApplicationTests {

	@Test
	void contextLoads() {
	}

}
